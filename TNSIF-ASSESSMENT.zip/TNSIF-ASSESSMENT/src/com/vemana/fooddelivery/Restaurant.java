package com.vemana.fooddelivery;



import java.util.*;

public class Restaurant {
    private int id;
    private String name;
    private List<FoodItem> menu;

    public Restaurant(int id, String name) {
        this.id = id;
        this.name = name;
        this.menu = new ArrayList<>();
    }

    public int getId() { return id; }
    public String getName() { return name; }
    public List<FoodItem> getMenu() { return menu; }

    public void addFoodItem(FoodItem item) {
        menu.add(item);
    }

    public void removeFoodItem(int foodId) {
        menu.removeIf(f -> f.getId() == foodId);
    }

    public String toString() {
        StringBuilder sb = new StringBuilder("Restaurant ID: " + id + ", Name: " + name + "\nMenu:\n");
        for (FoodItem item : menu) {
            sb.append("  ").append(item).append("\n");
        }
        return sb.toString();
    }
}

