package com.vemana.fooddelivery;



import java.util.Map;

public class CustomerService {
    private Map<Integer, Customer> customers;

    public CustomerService(Map<Integer, Customer> customers) {
        this.customers = customers;
    }

    public Customer registerCustomer(int id, String name, long contact) {
        Customer c = new Customer(id, name, contact);
        customers.put(id, c);
        return c;
    }

    public Customer getCustomer(int id) {
        return customers.get(id);
    }
}
