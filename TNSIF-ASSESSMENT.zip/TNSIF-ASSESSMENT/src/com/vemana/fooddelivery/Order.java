package com.vemana.fooddelivery;

import java.util.*;

public class Order {
    private static int counter = 1;
    private int orderId;
    private Customer customer;
    private Map<FoodItem, Integer> items;
    private String status;
    private DeliveryPerson deliveryPerson;
    private String deliveryAddress;

    public Order(Customer customer, String address) {
        this.orderId = counter++;
        this.customer = customer;
        this.items = new HashMap<>(customer.getCart().getItems());
        this.status = "Pending";
        this.deliveryAddress = address;
    }

    public int getOrderId() { return orderId; }
    public void setStatus(String status) { this.status = status; }
    public void setDeliveryPerson(DeliveryPerson dp) { this.deliveryPerson = dp; }

    public String toString() {
        StringBuilder sb = new StringBuilder("Order ID: " + orderId + ", Status: " + status + "\n");
        sb.append("Customer: ").append(customer.getUsername()).append(", Address: ").append(deliveryAddress).append("\n");
        for (Map.Entry<FoodItem, Integer> e : items.entrySet()) {
            sb.append("  ").append(e.getKey().getName()).append(" x ").append(e.getValue()).append("\n");
        }
        sb.append("Delivery Person: ").append(deliveryPerson != null ? deliveryPerson.getName() : "Not Assigned");
        return sb.toString();
    }
}

