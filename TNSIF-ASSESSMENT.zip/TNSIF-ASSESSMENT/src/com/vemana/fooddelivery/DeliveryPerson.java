package com.vemana.fooddelivery;


public class DeliveryPerson {
    private int deliveryPersonId;
    private String name;
    private long contactNo;

    public DeliveryPerson(int id, String name, long contactNo) {
        this.deliveryPersonId = id;
        this.name = name;
        this.contactNo = contactNo;
    }

    public int getId() { return deliveryPersonId; }
    public String getName() { return name; }

    public String toString() {
        return "DeliveryPerson [ID=" + deliveryPersonId + ", Name=" + name + ", Contact=" + contactNo + "]";
    }
}
