package com.vemana.fooddelivery;


public class Customer extends User {
    private Cart cart;

    public Customer(int id, String name, long contact) {
        super(id, name, contact);
        this.cart = new Cart();
    }

    public Cart getCart() { return cart; }

    public String toString() {
        return "Customer [ID=" + userId + ", Name=" + username + ", Contact=" + contactNo + "]";
    }
}

